package view;

import model.*;
import controller.*;

import java.awt.GridLayout;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.BorderLayout;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Draw extends JFrame {

	// class fields
	private static final long serialVersionUID = (long) 1;
	public static final int HEIGHT = 800;
	public static final int WIDTH = 800;

	private Controller controller;
	private JPanel content;
	private Setup setup;
	private String win = "";
	private DrawCase cases;

	// Constructor
	public Draw(Setup setup) {
		super("Ricochet Robot");
		this.setup = setup;
		this.setup.setup();

		this.setLayout(new BorderLayout());
		this.setResizable(false);
		this.setVisible(true);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		controller = new Controller(this.setup.getGrille(), this.setup.getPions(), this);
		this.addKeyListener(controller);

		content = new JPanel();
		content.setLayout(new GridLayout(16, 16));
	}

	// Getters
	public Setup getSetup() {
		return this.setup;
	}

	// Setters
	public void setWin(String s) {
		this.win = s;
	}

	// Class Methods

	public void update() throws Exception {
		this.content.removeAll();
		this.getContentPane().removeAll();
		this.draw();
	}

	public void updateSetup(Setup s) {
		s.setup();
		this.setup = s;
	}

	public void draw() throws  Exception, IndexOutOfBoundsException{
		Grille grille = this.setup.getGrille();
		for (int i = 0; i < grille.getHeight(); i++) {
			for (int j = 0; j < grille.getWidth(); j++) {
				cases = new DrawCase(grille.getGrille()[i][j], setup.getPions());
				cases.setPreferredSize(new Dimension(WIDTH / 16, HEIGHT / 16));
				content.add(cases);
			}
		}

		JLabel label = new JLabel(win);
		label.setFont(new Font("Arial", Font.BOLD, 30));
		label.setPreferredSize(new Dimension(WIDTH, 50));

		this.getContentPane().add(content);
		this.getContentPane().add(label, BorderLayout.SOUTH);

		this.pack();
	}

}
