package view;

import model.*;

import java.util.ArrayList;
import java.awt.Color;
import java.awt.Graphics;

import javax.swing.JPanel;

public class DrawCase extends JPanel {

	// class fields
	private static final long serialVersionUID = (long) 1;
	private Case cases;
	private ArrayList<Pions> p;

	// Constructor
	public DrawCase(Case cases, ArrayList<Pions> p) {
		this.cases = cases;
		this.p = p;
	}

	// Class Methods
	@Override
	public void paintComponent(Graphics g) {

		super.paintComponent(g);
		g.drawRect(0, 0, Draw.HEIGHT / 16, Draw.WIDTH / 16);

		if (!p.isEmpty()) {

			for (Pions p : this.p) {
				if (this.cases.equals(p.getPosition())) {
					g.setColor(this.getColor(p.getColor()));
					switch (p.getType()) {
						case "target":
							g.fillRect(1, 1, Draw.HEIGHT / 16, Draw.WIDTH / 16);
							break;

						case "robot":
							g.setColor(Color.BLACK);
							g.fillOval(5, 5, Draw.HEIGHT / 16 - 11, Draw.WIDTH / 16 - 11);

							g.setColor(this.getColor(p.getColor()));
							g.fillOval(7, 7, Draw.HEIGHT / 16 - 15, Draw.WIDTH / 16 - 15);

							break;

					}
				}
				if (cases.getPassageSolver()) {
					g.setColor(this.getColor(cases.getColor()));
					g.fillOval(17, 17, Draw.HEIGHT / 16 - 35, Draw.WIDTH / 16 - 35);
				}
			}
		}

		for (int i = 0; i < cases.getMurs().length; i++) {
			g.setColor(Color.BLACK);
			if (cases.getMurs()[i]) {
				switch (i) {
					case 0:
						g.fillRect(0, 0, Draw.WIDTH / 16, 5);
						break;
					case 1:
						g.fillRect(Draw.WIDTH / 16 - 5, 0, 5, Draw.HEIGHT / 16);
						break;
					case 2:
						g.fillRect(0, Draw.HEIGHT / 16 - 5, Draw.WIDTH / 16, 5);
						break;
					case 3:
						g.fillRect(0, 0, 5, Draw.HEIGHT / 16);
				}
			}

		}

		this.repaint();
	}

	private Color getColor(String color) {
		switch (color) {
			case "vert":
				return Color.GREEN;
			case "jaune":
				return Color.YELLOW;
			case "rouge":
				return Color.RED;
			case "bleu":
				return Color.BLUE;
			default:
				return Color.BLACK;
		}
	}

}
