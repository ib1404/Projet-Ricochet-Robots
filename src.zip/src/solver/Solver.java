package solver;

import model.*;

import java.util.Map;
import java.util.HashMap;
import java.util.ArrayList;

public class Solver {

	// Class Attributes
	private Pions robot;
	private ArrayList<Pions> pions;
	private Grille g;
	private ArrayList<Pions> secondaryPions;
	private int depth;
	private Case startCase;
	private ArrayList<String> currentPath;
	private Case endCase;
	private Pions primaryPion;
	private int noeuds;
	private HashMap<Case, ArrayList<Pions>> listRobotsToMove;
	private HashMap<Case, ArrayList<String>> moveList;
	private ArrayList<Case> path;

	// Constructor
	public Solver(Grille g, ArrayList<Pions> p, Pions r) {
		this.pions = p;
		this.robot = r;
		this.g = g;

		// initialize all fields
		secondaryPions = new ArrayList<>();
		depth = 0;
		startCase = null;
		currentPath = new ArrayList<>();
		endCase = null;
		primaryPion = null;
		noeuds = 0;
		listRobotsToMove = new HashMap<>();
		moveList = new HashMap<>();
		path = new ArrayList<>();

	}

	// Class Methods

	private ArrayList<String> bfs(ArrayList<Pions> robotsToMove, ArrayList<Case> did, int depth,
			ArrayList<String> currentPath, Case previous, HashMap<Case, ArrayList<Pions>> listRobotsToMove)
			throws Exception {
		int max = 0;
		if (this.g.getCase(this.primaryPion.getPosition()).getNumber() > 1) {
			if (this.depth > 10) {
				max = 11;
			} else if (this.depth == 0) {
				max = 1;
			} else if (this.depth > 0) {
				max = this.depth + this.g.getCase(this.primaryPion.getPosition()).getNumber() - 1;
			}
			if ((depth < max) || (currentPath.isEmpty())) {
				for (Pions current : robotsToMove) {
					Case caseTmp = new Case(current.getPosition()[0], current.getPosition()[1]);

					caseTmp.setColor(current.getColor());
					caseTmp.setNumber(depth);
					caseTmp.previous = previous;

					boolean move = true;
					int size = 0;

					if (did.isEmpty()) {
						did.add(caseTmp);
						size = 1;
						System.out.println(current.getColor());
					}

					if (depth != 0) {
						listRobotsToMove.put(caseTmp, robotsToMove);
					}

					if (previous != null) {
						if (current.equals(previous.getPosition())) {
							move = false;
						}
						if (previous.previous != null && previous.getColor().equals(caseTmp.getColor())) {

							if (previous.previous.getPosition()[0] == previous.getPosition()[0]
									&& previous.getPosition()[0] == caseTmp.getPosition()[0]) {
								move = false;
							}
							if (previous.previous.getPosition()[1] == previous.getPosition()[1]
									&& previous.getPosition()[1] == caseTmp.getPosition()[1]) {
								move = false;
							}
						}
					}

					int x = 0;

					if (!this.listRobotsToMove.isEmpty()) {
						for (Map.Entry<Case, ArrayList<Pions>> e : this.listRobotsToMove.entrySet()) {
							for (Pions p : robotsToMove) {
								for (Pions p2 : e.getValue()) {
									if (p.getColor().equals(p2.getColor()) && p.equals(p2.getPosition())) {
										x++;

									}
								}
							}

							if (x == 3 && depth > e.getKey().getNumber()) {
								move = false;
							}
							x = 0;
							break;
						}
					}

					ArrayList<Case> neighbors = caseTmp.getNeighbors(g, current);

					if (move) {

						for (Case neighbor : neighbors) {
							int[] tmp = current.getPosition();
							neighbor = new Case(neighbor.getPosition()[0], neighbor.getPosition()[1]);
							neighbor.setColor(current.getColor());

							boolean already = false;

							for (Case c : did) {
								if (c.getColor().equals(neighbor.getColor()) && c.equals(neighbor.getPosition())) {
									already = true;
								}
							}
							this.noeuds++;

							if (!already) {
								did.add(neighbor);
								current.setPosition(neighbor.getPosition());

								primaryPion.setArray(robotsToMove);
								ArrayList<String> neighborPath = this.execAStar(startCase, endCase, primaryPion);

								if ((((currentPath.size() + this.depth > neighborPath.size() + depth)
										&& !currentPath.isEmpty()) || currentPath.isEmpty())
										&& !neighborPath.isEmpty()) {
									System.out.println((currentPath.size() + this.depth) + " > "
											+ (neighborPath.size() + depth) + " vide : " + currentPath.isEmpty());
									currentPath = neighborPath;
									neighbor.setNumber(depth + 1);
									neighbor.previous = caseTmp;
									this.newWay(neighbor, depth, listRobotsToMove, null);
								}
								currentPath = bfs(robotsToMove, did, depth + 1, currentPath, caseTmp, listRobotsToMove);
								did.remove(neighbor);
								current.setPosition(tmp);
							}
						}
					}

					if (size == 1 && depth == 0) {
						did = new ArrayList<>();
						System.out.println("fin de boucle -> did.size() = " + did.size());
						size = 0;
					}

					if (depth != 0) {
						listRobotsToMove.remove(caseTmp);
					}
				}
			}
		}
		return currentPath;
	}

	public void algoPlay(ArrayList<String> finalPathString, Pions p) throws Exception {
		for (String s : finalPathString) {

			switch (s) {
				case "bas":
					p.moveDown(g, true);
					break;
				case "droite":
					p.moveRight(g, true);
					break;
				case "gauche":
					p.moveLeft(g, true);
					break;
				case "haut":
					p.moveUp(g, true);
					break;
				default:
					break;
			}

		}
	}

	public void solve() throws Exception {

		ArrayList<String> finalPathString = null;
		String winColor = "";

		for (Pions p : pions) {
			if (p.getType().equals("target") && !p.getColor().equals("black")) {
				endCase = p.getCase();
				winColor = p.getColor();
			}
		}

		for (Pions p : pions) {
			if (p.getType().equals("robot")) {
				if (p.getColor().equals(winColor)) {
					startCase = p.getCase();
					primaryPion = p;
				} else {
					secondaryPions.add(p);
				}
			}
		}
		this.currentPath = execAStar(startCase, endCase, primaryPion);

		ArrayList<Pions> robotsToMove = this.secondaryPions;

		finalPathString = bfs(robotsToMove, new ArrayList<>(), 0, this.currentPath, null, new HashMap<>());

		if (!this.path.isEmpty()) {
			Case tmp = null;
			Case same = null;
			ArrayList<Case> listTmp = new ArrayList<>();
			for (Case c : this.path) {
				System.out.println(c.getColor() + " : " + c + " (coup numero " + c.getNumber() + ")");
				if (tmp != null) {
					if (!tmp.getColor().equals(c.getColor()) && listTmp.size() > 1) {
						if (same != null && same.getColor().equals(c.getColor())) {
							listTmp.add(same);
						}
						this.moveList.put(tmp, AlgoritmA.trad(listTmp));
						listTmp = new ArrayList<>();
						same = tmp;
					}
				}
				tmp = c;
				System.out.println("same : " + same + " et c : " + c);
				listTmp.add(c);
			}
			if (!listTmp.isEmpty()) {
				this.moveList.put(tmp, AlgoritmA.trad(listTmp));
			}
		}

		for (Map.Entry<Case, ArrayList<String>> e : this.moveList.entrySet()) {
			System.out.println(e.getKey().getColor() + " : " + e.getValue());
			for (Pions p : robotsToMove) {
				if (p.getColor().equals(e.getKey().getColor()) && !e.getValue().isEmpty()) {
					this.algoPlay(e.getValue(), p);
				}
			}
		}

		System.out.println("Le solveur a trouve : " + finalPathString);
		System.out
				.println("Realisable en : " + finalPathString.size() + " coups (Noeud(s) parcouru(s) : " + this.noeuds);

		this.algoPlay(finalPathString, this.robot);
	}

	private void newWay(Case neighbor, int depth, HashMap<Case, ArrayList<Pions>> listRobotsToMove,
			ArrayList<Case> reste) {

		this.listRobotsToMove = listRobotsToMove;
		this.path = new ArrayList<>();
		this.depth = depth;

		if (reste != null) {
			this.path = reste;
			System.out.println("reste non null et size = " + this.path.size());
		}

		this.path.add(neighbor);
		while (neighbor.previous != null) {
			this.path.add(neighbor.previous);
			neighbor = neighbor.previous;
		}
	}

	public ArrayList<String> execAStar(Case startCase, Case endCase, Pions robotTmp) {
		AlgoritmA algo = new AlgoritmA(this.g, startCase, endCase, robotTmp);
		algo.AStar();
		ArrayList<Case> finalPath = algo.getPath();
		return AlgoritmA.trad(finalPath);
	}
}
