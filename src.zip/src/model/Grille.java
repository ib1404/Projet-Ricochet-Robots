package model;

public class Grille implements Cloneable {
	// class fields
	protected int width;
	protected int height;
	private String objColor;
	private int[] objPos;
	private int[][] carre;
	protected Case[][] grille;

	// Constructor
	public Grille() {
		this.width = this.height = 16;
		this.grille = new Case[this.width][this.height];
		this.carre = new int[][] { { 7, 7 }, { 7, 8 }, { 8, 7 }, { 8, 8 } };
	}

	// Getters
	public int getHeight() {
		return this.height;
	}

	public int getWidth() {
		return this.width;
	}

	public int[][] getCarre() {
		return this.carre;
	}

	public Case[][] getGrille() {
		return this.grille;
	}

	public int[] getObjPos() {
		return this.objPos;
	}

	public String getObjColor() {
		return this.objColor;
	}

	// Setters
	public void setObjPos(int[] pos) {
		this.objPos = pos;
	}

	public void setObjColor(String color) {
		this.objColor = color;
	}

	// Class Methods

	public void buildGrille() {
		Case c = new Case(0, 0);
		for (int i = 0; i < this.height; i++) {
			for (int j = 0; j < this.width; j++) {
				c = new Case(i, j);
				this.grille[i][j] = c;
			}
		}
	}

	public void initMurs(int[][] mursL, int[][] mursH) throws Exception {

		for (int i = 0; i < this.height; i++) {
			for (int j = 0; j < this.width; j++) {
				if (j == 0)
					this.grille[i][j].setMurs(3);
				else if (j == 15)
					this.grille[i][j].setMurs(1);
				if (i == 0)
					this.grille[i][j].setMurs(0);
				else if (i == 15)
					this.grille[i][j].setMurs(2);
				
			}
		}

		for (int[] m : mursL) {
			this.getCase(m).setMurs(1);
			if (m[1] + 1 < 16) {
				int[] murL = new int[] { m[0], m[1] + 1 };
				this.getCase(murL).setMurs(3);
			}
		}

		for (int[] m : mursH) {
			this.getCase(m).setMurs(2);
			if (m[0] + 1 < 16) {
				int[] murH = new int[] { m[0] + 1, m[1] };
				this.getCase(murH).setMurs(0);
			}
		}
	}

	public Case getCase(int[] p) throws Exception {
		for (int i = 0; i < this.height; i++) {
			for (int j = 0; j < this.width; j++) {
				if (this.grille[i][j].equals(p)) 
					return this.grille[i][j];
			}
		}
		throw new Exception(
				"les coordonnees [" + p[0] + ", " + p[1] + "] ne correspondent pas a des cases de la grille. ");
	}

	@Override
	public Grille clone() throws CloneNotSupportedException {
		return (Grille) super.clone();
	}
}
