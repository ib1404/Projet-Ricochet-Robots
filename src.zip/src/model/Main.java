package model;

import view.*;

public class Main {

	public static void main(String[] args) {
		Setup setup = new Setup();

		Draw GUI = new Draw(setup);
		try {
			GUI.draw();
		} catch (Exception e) {
		}
		GUI.setLocationRelativeTo(null);
	}
}
