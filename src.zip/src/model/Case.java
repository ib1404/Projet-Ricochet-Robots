package model;

import java.util.ArrayList;

public class Case {

	protected boolean[] murs = { false, false, false, false };
	public Case previous;
	private int number;
	private boolean passageSolver = false;
	private int[] location;
	private int f, g, h;
	private String color;

	// Constructor
	public Case(int x, int y) {
		this.number = 0;
		this.h = 0;
		this.g = 0;
		this.f = 0;
		this.location = new int[] { x, y };
	}

	// Setters
	public void setPassageSolver(boolean bool) {
		this.passageSolver = bool;
	}

	public void setH(int h) {
		this.h = h;
	}

	public void setG(int g) {
		this.g = g;
	}

	public void setF(int f) {
		this.f = f;
	}

	public void setColor(String c) {
		this.color = c;
	}

	public void setNumber(int nb) {
		this.number = nb;
	}

	public void setMurs(int c) throws Exception {
		if (c > 3 || c < 0)
			throw new Exception("impossible d'ajouter ce mur, l'index " + c
					+ " n'existe pas. Celui ci dois etre compris entre 0 et 3 (inclu).");
		this.murs[c] = true;
	}

	// Getters
	public boolean getPassageSolver() {
		return this.passageSolver;
	}

	public int getNumber() {
		return this.number;
	}

	public boolean[] getMurs() {
		return this.murs;
	}

	public int getF() {
		return this.f;
	}

	public int getG() {
		return this.g;
	}

	public int[] getPosition() {
		return this.location;
	}

	public int getH() {
		return this.h;
	}

	public String getColor() {
		return this.color;
	}

	// Methods
	public int countWalls() {
		int count = 0;
		for (boolean m : this.murs) {
			if (m) {
				count++;
			}
		}
		return count;
	}

	public ArrayList<Case> getNeighbors(Grille g, Pions p) {
		ArrayList<Case> neighbors = new ArrayList<Case>();
		p.setPosition(this.location);
		try {
			p.moveDown(g, false);
			neighbors.add(g.getCase(p.getPosition()));
			p.setPosition(this.location);

			p.moveUp(g, false);
			neighbors.add(g.getCase(p.getPosition()));
			p.setPosition(this.location);

			p.moveRight(g, false);
			neighbors.add(g.getCase(p.getPosition()));
			p.setPosition(this.location);

			p.moveLeft(g, false);
			neighbors.add(g.getCase(p.getPosition()));
			p.setPosition(this.location);
		} catch (Exception e) {
			System.err.println("ERROR" + e);
		}
		return neighbors;
	}

	public boolean equals(int[] position) {
		return java.util.Arrays.equals(position, this.location);
	}

	@Override
	public String toString() {
		return "(" + this.location[0] + "," + this.location[1] + ")";
	}
}
